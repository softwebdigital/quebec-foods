<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<!--begin::Head-->
	<head><base href="<?php echo e(env("APP_URL")); ?>">
		<title>Quebec - <?php echo $__env->yieldContent('pageTitle'); ?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>" />
		<meta property="og:type" content="article" />
		<meta property="og:title" content="Quebec - <?php echo $__env->yieldContent('pageTitle'); ?>" />
		<meta property="og:url" content="<?php echo e(env('APP_URL')); ?>" />
		<meta property="og:site_name" content="<?php echo e(env('APP_NAME')); ?>" />
		<link rel="canonical" href="<?php echo e(env('APP_URL')); ?>" />
		<link rel="shortcut icon" href="<?php echo e(asset('assets/logo/Favicon.png')); ?>" />
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Stylesheets Bundle(used by all pages)-->
		<link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
		<link href="<?php echo e(asset('assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
		<!--end::Global Stylesheets Bundle-->
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="bg-body">
		<!--begin::Main-->
		<!--begin::Root-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Authentication - Sign-up -->
			
				<!--begin::Content-->
				<div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
					<!--begin::Logo-->
					<a href="/" class="mb-12">
						<img alt="Logo" src="<?php echo e(asset('assets/logo/medium.png')); ?>" class="h-100px" />
					</a>
					<!--end::Logo-->
					<!--begin::Wrapper-->

                        <?php echo $__env->yieldContent('content'); ?>

					<!--end::Wrapper-->
				</div>
				<!--end::Content-->
				<!--begin::Footer-->
				<div class="d-flex flex-center flex-column-auto p-10">
					<!--begin::Links-->
					<div class="d-flex align-items-center fw-bold fs-6">
						<a href="/" class="text-muted text-hover-primary px-2">About</a>
						<a href="/" class="text-muted text-hover-primary px-2">Contact</a>
						<a href="/" class="text-muted text-hover-primary px-2">Contact Us</a>
					</div>
					<!--end::Links-->
				</div>
				<!--end::Footer-->
			</div>
			<!--end::Authentication - Sign-up-->
		</div>
		<!--end::Root-->
		<!--end::Main-->
		<!--begin::Javascript-->
		<script>var hostUrl = "assets/";</script>
		<!--begin::Global Javascript Bundle(used by all pages)-->
		<script src="<?php echo e(asset('assets/plugins/global/plugins.bundle.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/js/scripts.bundle.js')); ?>"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Page Custom Javascript(used by this page)-->
		
		
        <?php echo $__env->yieldContent('script'); ?>
		<!--end::Page Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html>
<?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/layouts/auth.blade.php ENDPATH**/ ?>