<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
    <p style="font-size: 12px;">
        <a style="font-size: 12px;  margin-left: 5px; font-weigth: bold;" href="mailto:<?php echo e(env('ADMIN_EMAIL')); ?>">
            Write us a review
        </a> 
        <a style="font-size: 12px;  margin-left: 5px; font-weigth: bold;" href="mailto:<?php echo e(env('ADMIN_EMAIL')); ?>" href="<?php echo e(route('faq')); ?>">
            FAQ
        </a>
        <a style="font-size: 12px;  margin-left: 5px; font-weigth: bold;" href="#">
            Terms & Conditions
        </a>
    </p>
    <p style="font-size: 12px;">
        © <?php echo e(date('Y')); ?> 
        <a style="font-size: 12px; text-decoration: none; font-weigth: bold;" href="https://quebecagrifoodpro-coop.ng/" target="_blank">
            Quebec Food Processing 
        </a> 
        <a style="font-size: 12px; text-decoration: none; font-weigth: bold;" href="https://quebecgroups.com/" target="_blank">
            (Quebec Groups),
        </a>
            All rights reserved.
    </p>
    <p style="font-size: 12px;">
        Powered By 
        <a style="font-size: 12px; text-decoration: none; font-weigth: bold;" href="https://www.softwebdigital.com/" target="_blank">
            Soft-Web Digital
        </a>
    </p>

<!-- <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?> -->
</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>