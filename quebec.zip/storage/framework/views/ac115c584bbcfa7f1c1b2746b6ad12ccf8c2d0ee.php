<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Not Found')); ?>
<?php $__env->startSection('description', __('Oopps!! The page you were looking for doesn\'t exist.')); ?>

<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/errors/404.blade.php ENDPATH**/ ?>