<?php $__env->startSection('pageTitle', 'Package Details'); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadCrumbs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--begin::Layout-->
<div class="d-flex flex-column flex-lg-row">
    <!--begin::Sidebar-->
    <div class="flex-column flex-lg-row-auto w-lg-250px w-xl-350px mb-10">
        <!--begin::Card-->
        <div class="card mb-5 mb-xl-8">
            <!--begin::Card body-->
            <div class="card-body">
                <!--begin::Summary-->
                <!--begin::User Info-->
                <div class="d-flex flex-center flex-column py-5">
                    <?php if($package['cover']): ?>
                        <!--begin::Avatar-->
                        <div class="symbol symbol-100px symbol-circle mb-7">
                            <img src="assets/media/avatars/300-6.jpg" alt="image" />
                        </div>
                        <!--end::Avatar-->
                    <?php endif; ?>
                    <!--begin::Name-->
                    <a href="#" class="fs-3 text-gray-800 text-hover-primary fw-bolder mb-3"><?php echo e($package['name']); ?></a>
                    <!--end::Name-->
                    <!--begin::Position-->
                    <div class="mb-9">
                        <!--begin::Badge-->
                        <?php if($package['status'] == 'open'): ?>
                            <span class="badge badge-lg badge-light-primary d-inline"><?php echo e(ucwords($package['status'])); ?></span>
                        <?php else: ?>
                            <span class="badge badge-lg badge-light-danger d-inline"><?php echo e(ucwords($package['status'])); ?></span>
                        <?php endif; ?>
                        <!--begin::Badge-->
                    </div>
                    <div class="mb-9">
                        <!--begin::Badge-->
                        <div class="d-inline"><?php echo e(ucwords($package['description'])); ?></div>
                        <!--begin::Badge-->
                    </div>
                    <!--end::Position-->
                    <!--begin::Info-->
                    <div class="d-flex flex-wrap flex-center">
                        <!--begin::Stats-->
                        <!-- <div class="border border-gray-300 border-dashed rounded py-3 px-3 mb-3">
                            <div class="fs-4 fw-bolder text-gray-700">
                                <span class="w-120px"><?php echo e(ucfirst($package['type'])); ?></span>
                            </div>
                            <div class="fw-bold text-muted">Type</div>
                        </div> -->
                        <!--end::Stats-->
                        <!--begin::Stats-->
                        <!-- <div class="border border-gray-300 border-dashed rounded py-3 px-3 mb-3 ms-5">
                            <div class="fs-4 fw-bolder text-gray-700">
                                <span class="w-100px"><?php echo e($package['roi']); ?>%</span>
                            </div>
                            <div class="fw-bold text-muted">ROI</div>
                        </div> -->
                        <!--end::Stats-->
                    </div>
                    <!--end::Info-->
                </div>
                <div class="separator mb-md-10"></div>
                <!--end::Summary-->
                <!--begin::Details toggle-->
                <div class="d-flex flex-stack fs-4 py-3">
                    <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="#kt_user_view_details" role="button" aria-expanded="false" aria-controls="kt_user_view_details">Packages Details
                    <span class="ms-2 rotate-180">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                        <span class="svg-icon svg-icon-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="black" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </span></div>
                </div>
                <!--end::Details toggle-->
                <!--begin::Details content-->
                <div id="kt_user_view_details" class="collapse show">
                    <div class="pb-5 fs-6">
                        <!--begin::Details item-->
                        <div class="fw-bolder mt-5">Type</div>
                        <div class="text-gray-600"><?php echo e(ucfirst($package['type'])); ?></div>
                        <div class="fw-bolder mt-5">ROI</div>
                        <div class="text-gray-600"><?php echo e($package['roi']); ?>%</div>
                        <!--begin::Details item-->
                        <!--begin::Details item-->
                        <div class="fw-bolder mt-5">Start Date</div>
                        <div class="text-gray-600">
                            <a href="#" class="text-gray-600 text-hover-primary"><?php echo e($package['start_date']->format('M d, Y \a\t h:i A')); ?></a>
                        </div>
                        <!--begin::Details item-->
                        <!--begin::Details item-->
                        <?php if($package['type'] == 'farm'): ?>
                            <div class="fw-bolder mt-5">Total Available Slots</div>
                            <div class="text-gray-600"><?php echo e($package['slots']); ?></div>

                            <div class="fw-bolder mt-5">Duration Mode</div>
                            <div class="text-gray-600"><?php echo e($package['duration_mode']); ?></div>
                        <?php endif; ?>

                        <?php if($package['type'] == 'plant'): ?>
                            <div class="fw-bolder mt-5">Milestones</div>
                            <div class="text-gray-600"><?php echo e($package['milestones']); ?></div>

                            <div class="fw-bolder mt-5">Payout Mode</div>
                            <div class="text-gray-600"><?php echo e($package['payout_mode']); ?></div>
                        <?php endif; ?>
                        <!--begin::Details item-->
                        <!--begin::Details item-->
                    </div>
                </div>
                <!--end::Details content-->
            </div>
            <!--end::Card body-->
        </div>
        <!--end::Card-->
    </div>
</div>
<!--end::Layout-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sanni Davi\Documents\Soft-Web Digitals\quebec-foods\resources\views/admin/package/show.blade.php ENDPATH**/ ?>