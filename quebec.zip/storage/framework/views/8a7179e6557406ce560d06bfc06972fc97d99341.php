

<?php $__env->startSection('pageTitle', ucfirst($type).' Packages'); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadCrumbs'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.packages', $type)); ?>" class="<?php if(request()->routeIs(['admin.packages'])): ?> text-dark <?php else: ?> text-muted <?php endif; ?>"><?php echo e(ucfirst($type)); ?> Package</a></li>
<li class="breadcrumb-item"><a href="javascript:void()" class="text-dark">Create <?php echo e(ucfirst($type)); ?> Package</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--begin::Content-->
<div class="flex-lg-row-fluid me-lg-7 me-xl-10">
    <!--begin::Card-->
    <div class="row">
        <div class="col-md-8">
            <div class="card ">
                <div class="card-body p-9">
                    <!--begin::Card title-->
                    <div class="card-title flex-column">
                        <h4 class="mb-5">Create <?php echo e(ucfirst($type)); ?> Package</h4>
                    </div>
                    <!--end::Card title-->
                    <!--begin:::Form-->
                    <form class="form mb-3" method="post" action="<?php echo e(route('admin.packages.store')); ?>" id="createPackageForm" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e(strtolower($type)); ?>" name="type">
                        <?php if($type == 'plant'): ?>
                            <!--begin::Image input-->
                            <div class="image-input image-input-empty mb-5" data-kt-image-input="true">
                                <!--begin::Image preview wrapper-->
                                <div class="image-input-wrapper w-125px h-125px" style="background: url(<?php echo e(asset('assets/media/avatars/image_placeholder.png')); ?>) center/cover no-repeat;"></div>
                                <!--end::Image preview wrapper-->

                                <!--begin::Edit button-->
                                <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                data-kt-image-input-action="change"
                                data-bs-toggle="tooltip"
                                data-bs-dismiss="click"
                                title="Change image">
                                <i class="bi bi-pencil-fill fs-7"></i>

                                <!--begin::Inputs-->
                                <input type="file" name="image" id="image" accept=".png, .jpg, .jpeg" />
                                <input type="hidden" name="image_remove" id="image_remove" />
                                <!--end::Inputs-->
                                </label>
                                <!--end::Edit button-->

                                <!--begin::Cancel button-->
                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                data-kt-image-input-action="cancel"
                                data-bs-toggle="tooltip"
                                data-bs-dismiss="click"
                                title="Cancel image">
                                <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Cancel button-->

                                <!--begin::Remove button-->
                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                data-kt-image-input-action="remove"
                                data-bs-toggle="tooltip"
                                data-bs-dismiss="click"
                                title="Remove image">
                                <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Remove button-->
                            </div>
                            <!--end::Image input-->
                            <div>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small d-block" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="name">Name</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="text" placeholder="Package name" value="<?php echo e(old("name")); ?>" class="form-control form-control-solid" name="name" id="name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger small" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mt-4 mb-5 fv-row">
                            <!--end::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="description">Description</label>
                            <!--end::Label-->
                            <!--end::Input-->
                            <textarea placeholder="Description" style="resize: none" class="form-control form-control-solid" name="description" id="description" rows="5"><?php echo e(old("description")); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger small" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($type == 'farm'): ?>
                        <!--end::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="category">Category</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <select name="category" aria-label="Select the package category" data-placeholder="Select the package category" data-control="select2" class="form-select form-select-solid text-dark" id="category">
                                <option value=""></option>
                                <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if(old('category') == $category['id']): ?> selected <?php endif; ?> value="<?php echo e($category['id']); ?>"><?php echo e($category['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php endif; ?>
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--end::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="roi">ROI in %</label>
                            <!--end::Label-->
                            <!--end::Input-->
                            <input type="number" placeholder="ROI" value="<?php echo e(old("roi")); ?>" class="form-control form-control-solid" name="roi" id="roi">
                            <?php $__errorArgs = ['roi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger small" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--end::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="price">Price per Slot</label>
                            <!--end::Label-->
                            <!--end::Input-->
                            <input type="number" placeholder="Price per Slot" value="<?php echo e(old("price")); ?>" class="form-control form-control-solid" name="price" id="price">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger small" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="mb-5">
                            <label class="required fs-5 fw-bold mb-2" for="start_date">Start Date</label>
                            <input class="form-control form-control-solid" placeholder="Start Date" id="kt_daterangepicker_3" value="<?php echo e(old('start_date')); ?>" name="start_date" id="startDate" />
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger small" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!--end::Input group-->
                        <?php if($type == 'farm'): ?>
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--end::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="slot">Total Available Slots</label>
                            <!--end::Label-->
                            <!--end::Input-->
                            <input type="text" placeholder="Total Available Slots" value="<?php echo e(old("slots")); ?>" class="form-control form-control-solid" name="slots" id="slots">
                            <?php $__errorArgs = ['slots'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger small" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!--end::Input group-->
                        <?php endif; ?>
                        <?php if($type == 'plant'): ?>
                            <!--begin::Input group-->
                            <div class="d-flex flex-column mb-5 fv-row">
                                <!--end::Label-->
                                <label class="required fs-5 fw-bold mb-2" for="duration">Milestones</label>
                                <!--end::Label-->
                                <!--end::Input-->
                                <input onkeyup="getVal()" type="number" placeholder="No of Milestones" value="<?php echo e(old("milestones")); ?>" class="form-control form-control-solid" name="milestones" id="milestones">
                                <?php $__errorArgs = ['milestones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger small" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--end::Input group-->
                        <?php endif; ?>
                        <?php if($type == 'farm'): ?>
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="duration_mode">Duration Mode</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <select name="duration_mode" aria-label="Select the duration mode" data-placeholder="Select the duration mode" data-control="select2" class="form-select form-select-solid text-dark" id="durationMode">
                                <option value=""></option>
                                <option <?php if(old('duration_mode') == 'day'): ?> selected <?php endif; ?> value="day">Days</option>
                                <option <?php if(old('duration_mode') == 'month'): ?> selected <?php endif; ?> value="month">Months</option>
                                <option <?php if(old('duration_mode') == 'year'): ?> selected <?php endif; ?> value="year">Years</option>
                            </select>
                            <?php $__errorArgs = ['duration_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-5 fv-row">
                            <!--end::Label-->
                            <label class="required fs-5 fw-bold mb-2" for="duration">Duration</label>
                            <!--end::Label-->
                            <!--end::Input-->
                            <input type="text" placeholder="Duration" value="<?php echo e(old("duration")); ?>" class="form-control form-control-solid" name="duration" id="duration">
                            <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php endif; ?>
                        <!--end::Input group-->
                        <?php if($type == 'plant'): ?>
                            <!--begin::Input group-->
                            <div class="d-flex flex-column mb-5 fv-row">
                                <!--begin::Label-->
                                <label class="required fs-5 fw-bold mb-2" for="payout_mode">Payout Mode</label>
                                <!--end::Label-->
                                <!--begin::Input-->
                                <select onchange="getVals()" name="payout_mode" aria-label="Select the payout mode" data-placeholder="Select the payout mode" data-control="select2" class="form-select form-select-solid text-dark" id="payoutMode">
                                    <option value=""></option>
                                    <option <?php if(old('payout_mode') == 'monthly'): ?> selected <?php endif; ?> value="monthly">Monthly</option>
                                    <option <?php if(old('payout_mode') == 'quarterly'): ?> selected <?php endif; ?> value="quarterly">Quarterly</option>
                                    <option <?php if(old('payout_mode') == 'semi-annually'): ?> selected <?php endif; ?> value="semi-annually">Semi Annually (Half a year)</option>
                                    <option <?php if(old('payout_mode') == 'annually'): ?> selected <?php endif; ?> value="annually">Annually</option>
                                    <option <?php if(old('payout_mode') == 'biannually'): ?> selected <?php endif; ?> value="biannually">Biannually</option>
                                </select>
                                <?php $__errorArgs = ['payout_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger small" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <div class="small mt-4" id="statement" style="display: none;">
                                    <strong>Investments will run for <span id="year-value" ></span> with <span id="milestones-value" ></span> payment milestones</strong>
                                </div>
                            </div>
                            <!--end::Input group-->
                            <div class="my-4">
                                <!--end::Label-->
                                <div class="form-check form-switch form-check-custom form-check-solid my-7">
                                    <label class="form-check-label fs-5 fw-bold mb-2" for="makePackageOpen" style="margin-right: 4px;">
                                        Package Status 
                                    </label><p id="active" style="margin: 0px 10px 0px 5px; font-size: 10px;">(Inactive)</p>
                                    <input class="form-check-input mb-2 h-20px w-30px" type="checkbox"
                                        <?php if(old('status') == 'open'): ?> checked <?php endif; ?> name="status" value="open"
                                        id="makePackageOpen" onchange="doalert(this)" />
                                    
                                </div>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="small text-danger">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
        
                        <?php endif; ?>
                        <?php if($type == 'farm'): ?>
                            <div class="form-check form-switch form-check-custom form-check-solid my-7">
                                <input class="form-check-input mb-2 h-20px w-30px" type="checkbox" name="rollover" value="1" id="makePackageRollover"/>
                                <label class="form-check-label fs-5 fw-bold mb-2" for="makePackageRollover">
                                        Enable rollover
                                </label>
                            </div>
                            <?php $__errorArgs = ['rollover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="small text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>

                        <!--begin::Submit-->
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create Packages')): ?>
                            <button type="button" onclick="confirmFormSubmit(event, 'createPackageForm')" class="btn btn-primary w-100">
                                <!--begin::Indicator-->
                                <span class="indicator-label">Create Package</span>
                                <!--end::Indicator-->
                            </button>
                        <?php endif; ?>
                        <!--end::Submit-->
                    </form>
                    <!--end:::Form-->
                </div>
            </div>
        </div>
    </div>
    <!--end::Card-->
</div>
<script>
    var active = document.getElementById('active');
    const mV = document.getElementById('milestones-value');
    
    function doalert(checkboxElem) {
        if (checkboxElem.checked) {
            // active.style.display = "block"
            active.innerText = '(Active)'
        } else {
            // active.style.display = "none"
            active.innerText = '(Inactive)'
        }
    }

    const yV = document.getElementById('year-value');
    const nY = document.getElementById('numberOfYears');

    function getVal() {
        const milestones = document.getElementById('milestones').value;
        // console.log(milestones);
        mV.innerText = milestones
        nY.innerText = milestones
    }
    function getVals() {
        const sT = document.getElementById('statement');
        const milestones = document.getElementById('milestones').value;
        if (milestones == null) {
            sT.style = 'none'
        } else {
            sT.style = 'block'
        }
        
        const pM = document.getElementById('payoutMode').value;
        console.log(milestones)

        if (pM == "monthly") {
            yV.innerText = "a month"
        }
        if (pM == "quarterly") {
            yV.innerText = "3 months"
        }
        if (pM == "semi-annually") {
            yV.innerText = "6 months"
        }
        if (pM == "annually") {
            yV.innerText = "a year"
        }
        if (pM == "biannually") {
            yV.innerText = "2 years"
        }

    }
</script>
<!--end::Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('#data-table').DataTable({
            "searching": true,
            "lengthMenu": [[100, 200, 300, 400], [100, 200, 300, 400]]
        });
    });

    $("#kt_daterangepicker_3").daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        minYear: 1901,
        maxYear: parseInt(moment().format("YYYY"),10),
        timePicker: true,
        startDate: moment().startOf("hour"),
        locale: {
            format: "YYYY-MM-DD HH:mm:ss"
        }
    },
);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sanni Davi\Documents\Soft-Web Digitals\quebec-foods\resources\views/admin/package/create.blade.php ENDPATH**/ ?>