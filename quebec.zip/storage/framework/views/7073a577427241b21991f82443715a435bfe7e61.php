[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\Sanni Davi\Documents\Soft-Web Digitals\quebec-foods\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>