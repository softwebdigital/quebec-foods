<?php echo e($slot); ?>

<?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>