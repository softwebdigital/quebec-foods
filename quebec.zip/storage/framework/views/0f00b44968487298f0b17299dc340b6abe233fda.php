<?php echo e($slot); ?>

<?php /**PATH C:\Users\Sanni Davi\Documents\Soft-Web Digitals\quebec-foods\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>