<tr>
    <td class="header">
    <a href="<?php echo e($url); ?>" style="display: inline-block;">
    <?php if(trim($slot) === 'Laravel'): ?>
    <img src="https://laravel.com/img/notification-logo.png" class="logo" alt="Laravel Logo">
    <?php else: ?>
    <a href="<?php echo e(url('/')); ?>" style="text-decoration: none">
        <img src="<?php echo e(asset('assets/logo/medium.png')); ?>" style="width: 150px" alt>
    </a>
    <?php endif; ?>
    </a>
    </td>
    </tr>
<?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>