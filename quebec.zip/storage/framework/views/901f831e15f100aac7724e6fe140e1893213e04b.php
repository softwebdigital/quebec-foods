<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>