<?php $__env->startSection('pageTitle', 'Verify Email'); ?>

<?php $__env->startSection('content'); ?>
<!--begin::Wrapper-->
<div class="pt-lg-10 mb-10 text-center">
    <!--begin::Logo-->
    <h1 class="fw-bolder fs-2qx text-gray-800 mb-7">Verify Your Email</h1>
    <!--end::Logo-->
    <!--begin::Message-->
    <?php if(session('resent')): ?>
        <div class="d-flex align-items-center bg-success rounded p-5 mb-7">
            <span class="svg-icon svg-icon-success me-3">
                <i class="fas fa-check-circle text-light" style="width: 18px"></i>
            </span>
            <div class="flex-grow-1 me-2">
                <span class="fw-bolder text-light text-hover-primary fs-6"><?php echo e(__('A fresh verification link has been sent to your email address.')); ?></span>
            </div>
        </div>
    <?php endif; ?>
    <div class="fs-3 fw-bold text-muted mb-10">We have sent an email to
    <span class="link-primary fw-bolder"><?php echo e(auth()->user()->email); ?></span>
    <br />pelase follow a link to verify your email.</div>
    <!--end::Message-->
    <!--begin::Action-->
    <div class="text-center mb-10">
        <form class="d-inline" method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-lg btn-primary fw-bolder"><?php echo e(__('Use a different email address')); ?></button>.
        </form>
    </div>
    <!--end::Action-->
    <!--begin::Action-->
    <div class="fs-5">
        <span class="fw-bold text-gray-700">Did’t receive an email?</span>
        <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('Resend')); ?></button>.
        </form>
    </div>
    <!--end::Action-->
</div>
<!--end::Wrapper-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sanni Davi\Desktop\quebec\resources\views/auth/verify.blade.php ENDPATH**/ ?>